module.exports = async (sock, msg) => {
  const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text;
  if (!text) return;
  const jid = msg.key.remoteJid;

  if (text.toLowerCase() === 'ping') {
    await sock.sendMessage(jid, { text: 'Pong 🏓' });
  }

  if (text.toLowerCase() === 'menu') {
    await sock.sendMessage(jid, {
      text: `📜 Menu:\n\n1. !sticker\n2. !ytmp3 <link>\n3. !ytmp4 <link>\n4. !tiktok <link>\n5. !ai <tanya>\n6. !image <deskripsi>\n7. !broadcast <pesan>\n8. !joingc <link>`
    });
  }
};