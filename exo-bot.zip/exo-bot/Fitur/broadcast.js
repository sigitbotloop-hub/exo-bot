module.exports = async (sock, msg) => {
  const text = msg.message?.conversation || "";
  if (!text.startsWith("!broadcast ")) return;

  const pesan = text.replace("!broadcast ", "");
  const kontak = await sock.groupFetchAllParticipating();

  for (let jid in kontak) {
    await sock.sendMessage(jid, { text: `📢 Broadcast:\n${pesan}` });
  }

  await sock.sendMessage(msg.key.remoteJid, { text: "✅ Broadcast selesai." });
};