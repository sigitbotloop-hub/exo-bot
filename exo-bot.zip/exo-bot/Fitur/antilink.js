module.exports = async (sock, msg) => {
  const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text;
  if (!text || !text.includes("chat.whatsapp.com")) return;

  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || msg.key.remoteJid;

  await sock.sendMessage(jid, {
    text: `⚠️ Link grup terdeteksi. @${sender.split('@')[0]} akan dikeluarkan.`,
    mentions: [sender]
  });

  await sock.groupParticipantsUpdate(jid, [sender], "remove");
};