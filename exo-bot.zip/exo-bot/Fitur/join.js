module.exports = async (sock, msg) => {
  const text = msg.message?.conversation || "";
  if (!text.startsWith("!joingc ")) return;

  const invite = text.replace("!joingc ", "").split("/").pop();
  await sock.groupAcceptInvite(invite);
};