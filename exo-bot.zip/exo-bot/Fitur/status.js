module.exports = async (sock, msg) => {
  const text = msg.message?.conversation || "";
  if (text === "!status") {
    const statuses = await sock.fetchStatus(msg.key.participant);
    await sock.sendMessage(msg.key.remoteJid, { text: JSON.stringify(statuses) });
  }
};