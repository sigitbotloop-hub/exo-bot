const axios = require("axios");

module.exports = async (sock, msg) => {
  const text = msg.message?.conversation || "";
  const jid = msg.key.remoteJid;

  if (text.startsWith("!ai ")) {
    const prompt = text.replace("!ai ", "");
    const res = await axios.post("https://api.aibot.com/chat", { prompt });
    await sock.sendMessage(jid, { text: res.data.reply || "Maaf, error." });
  }
};