const { writeFileSync } = require("fs");
const { exec } = require("child_process");

module.exports = async (sock, msg) => {
  const media = msg.message?.imageMessage;
  if (!media) return;

  const buffer = await sock.downloadMediaMessage(msg);
  writeFileSync("temp.jpg", buffer);
  exec("ffmpeg -i temp.jpg -vf scale=512:512 temp.webp", async () => {
    const sticker = require("fs").readFileSync("temp.webp");
    await sock.sendMessage(msg.key.remoteJid, { sticker });
  });
};