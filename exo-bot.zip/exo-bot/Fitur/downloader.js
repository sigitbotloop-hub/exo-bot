const axios = require("axios");

module.exports = async (sock, msg) => {
  const text = msg.message?.conversation || "";
  const jid = msg.key.remoteJid;

  if (text.startsWith("!ytmp3 ")) {
    const url = text.replace("!ytmp3 ", "");
    await sock.sendMessage(jid, { text: `🔗 Download lagu dari: ${url}` });
    // contoh doang, belum download beneran
  }
};