module.exports = async (sock, msg) => {
  const text = msg.message?.conversation || "";
  const jid = msg.key.remoteJid;

  // Anti Capslock
  if (text.length > 8 && text === text.toUpperCase()) {
    await sock.sendMessage(jid, { text: "⚠️ Tolong jangan capslock ya..." });
  }

  // Anti Virtex
  if (text.length > 1000) {
    await sock.sendMessage(jid, { text: "🚫 Pesan terlalu panjang, terdeteksi spam!" });
  }
};