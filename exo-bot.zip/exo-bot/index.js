const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require("@whiskeysockets/baileys");
const pino = require("pino");

const autorespon = require("./fitur/autorespon");
const welcome = require("./fitur/welcome");
const antilink = require("./fitur/antilink");
const broadcast = require("./fitur/broadcast");
const sticker = require("./fitur/sticker");
const downloader = require("./fitur/downloader");
const ai = require("./fitur/ai");
const join = require("./fitur/join");
const status = require("./fitur/status");
const protect = require("./fitur/protect");

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState("auth");
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    logger: pino({ level: "silent" }),
    printQRInTerminal: true,
    auth: state,
    version
  });

  sock.ev.on("creds.update", saveCreds);
  sock.ev.on("group-participants.update", async (update) => welcome(sock, update));
  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    await autorespon(sock, msg);
    await antilink(sock, msg);
    await broadcast(sock, msg);
    await sticker(sock, msg);
    await downloader(sock, msg);
    await ai(sock, msg);
    await join(sock, msg);
    await status(sock, msg);
    await protect(sock, msg);
  });
}

startBot();